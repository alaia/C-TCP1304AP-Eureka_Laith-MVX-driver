//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Buttons.hpp>

/*#define CCD_STOP        0x00;
#define CCD_START       0x01;
#define SINGLE_MODE     0x01;
#define RUN_MODE	0x02;
#define EXT_MODE	0x04;
#define DARK_MODE	0x08;
#define MODE_DENIED_BIT 0x80;
#define FALLING_EDGE    0x00;
#define RISING_EDGE     0x01;*/

//---------------------------------------------------------------------------
class TfmMain : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar;
        TChart *Chart1;
        TFastLineSeries *Series1;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Info1;
        TMenuItem *Exit1;
        TPanel *Panel1;
        TMenuItem *Devices1;
        TMenuItem *Enumerate1;
        TMenuItem *CloseDevice1;
        TMenuItem *N1;
        TMenuItem *Settings1;
        TMenuItem *SyncParam1;
        TMenuItem *N2;
        TMenuItem *Mode1;
        TMenuItem *IntegrationTime1;
        TMenuItem *VRef1;
        TMenuItem *SaveParameter1;
        TMenuItem *N3;
        TMenuItem *DarkSignal1;
        TMenuItem *ClearDarkSignal1;
        TMenuItem *Single1;
        TMenuItem *Run1;
        TMenuItem *External1;
        TMenuItem *FallingEdge1;
        TMenuItem *RisingEdge1;
        TMenuItem *SystemVRef1;
        TMenuItem *ADVRef1;
        TMenuItem *SignalVRef1;
        TBitBtn *BtnStart;
        TBitBtn *BtnStop;
        void __fastcall SelectDevClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall Exit1Click(TObject *Sender);
        void __fastcall Enumerate1Click(TObject *Sender);
        void __fastcall CloseDevice1Click(TObject *Sender);
        void __fastcall SyncParam1Click(TObject *Sender);
        void __fastcall ModeClick(TObject *Sender);
        void __fastcall IntegrationTime1Click(TObject *Sender);
        void __fastcall SystemVRef1Click(TObject *Sender);
        void __fastcall ADVRef1Click(TObject *Sender);
        void __fastcall SignalVRef1Click(TObject *Sender);
        void __fastcall SaveParameter1Click(TObject *Sender);
        void __fastcall DarkSignal1Click(TObject *Sender);
        void __fastcall ClearDarkSignal1Click(TObject *Sender);
        void __fastcall BtnStartClick(TObject *Sender);
        void __fastcall BtnStopClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        typedef struct TCCDParam {
                BYTE    ucStart;
                BYTE    ucMode;
                BYTE    ucEdge;
                DWORD   dwTint;
                float   fSystemVRef;
                float   fADVRef;
                float   fSignalVRef;
        } stCCDParam;
        typedef BYTE (__stdcall *LPGETBYTE)(BYTE*, WORD);
        typedef DWORD (__stdcall *LPOPENDRIVER)();
        typedef DWORD (__stdcall *LPCLOSEDRIVER)();
        typedef BYTE (__stdcall *LPISDRIVEROPEN)();
        typedef DWORD (__stdcall *LPENUMDEVICES)(Shortint&);
        typedef DWORD (__stdcall *LPOPENUSB)(Shortint, void *);
        typedef DWORD (__stdcall *LPCLOSEUSB)();
        typedef BYTE (__stdcall *LPDEVICECOUNT)();
        typedef Shortint (__stdcall *LPCURRENTDEVICEINDEX)();
        typedef WORD (__stdcall *LPGETVID)(BYTE);
        typedef WORD (__stdcall *LPGETPID)(BYTE);
        typedef WORD (__stdcall *LPGETVERSION)(BYTE);
        typedef PCHAR (__stdcall *LPGETVENDORNAME)(BYTE);
        typedef PCHAR (__stdcall *LPGETPRODUCTNAME)(BYTE);
        typedef PCHAR (__stdcall *LPGETSERIALNUMBER)(BYTE);
        typedef PCHAR (__stdcall *LPGETERRORSTRING)(DWORD);
        typedef DWORD (__stdcall *LPRESUMEACQUISITION)();
        typedef DWORD (__stdcall *LPSETMODE)(BYTE&, BYTE&);
        typedef DWORD (__stdcall *LPSTART)(BYTE&, BYTE&, BYTE&);
        typedef DWORD (__stdcall *LPSTARTDARKSIGNAL)(BYTE&, BYTE&, BYTE&);
        typedef DWORD (__stdcall *LPCLEARDARKSIGNAL)();
        typedef DWORD (__stdcall *LPSETTINT)(DWORD&);
        typedef DWORD (__stdcall *LPREADPARAMS)(stCCDParam&);
        typedef DWORD (__stdcall *LPWRITEI2C)(BYTE&, BYTE[], WORD&, WORD&);
        typedef DWORD (__stdcall *LPREADI2C)(BYTE&, BYTE *, WORD&, WORD&);
        typedef DWORD (__stdcall *LPSETSYSTEMVREF)(float, BYTE&);
        typedef DWORD (__stdcall *LPSETADVREF)(float, BYTE&);
        typedef DWORD (__stdcall *LPSETSIGNALVREF)(float, BYTE&);
        typedef DWORD (__stdcall *LPSAVEPARAM)(BYTE&);

        HINSTANCE hDLL;
        LPGETBYTE               lpGetbyte;
        LPOPENDRIVER            lpOpenDriver;
        LPCLOSEDRIVER           lpCloseDriver;
        LPISDRIVEROPEN          lpIsDriverOpen;
        LPENUMDEVICES           lpEnumDevices;
        LPOPENUSB               lpOpenUSB;
        LPCLOSEUSB              lpCloseUSB;
        LPDEVICECOUNT           lpDeviceCount;
        LPCURRENTDEVICEINDEX    lpCurrentDeviceIndex;
        LPGETVID                lpGetVID;
        LPGETPID                lpGetPID;
        LPGETVERSION            lpGetVersion;
        LPGETVENDORNAME         lpGetVendorName;
        LPGETPRODUCTNAME        lpGetProductName;
        LPGETSERIALNUMBER       lpGetSerialNumber;
        LPGETERRORSTRING        lpGetErrorString;
        LPRESUMEACQUISITION     lpResumeAquisition;
        LPSETMODE               lpSetMode;
        LPSTART                 lpStart;
        LPSTARTDARKSIGNAL       lpStartDarkSignal;
        LPCLEARDARKSIGNAL       lpClearDarkSignal;
        LPSETTINT               lpSetTint;
        LPREADPARAMS            lpReadParams;
        LPWRITEI2C              lpWriteI2C;
        LPREADI2C               lpReadI2C;
        LPSETSYSTEMVREF         lpSetSystemVRef;
        LPSETADVREF             lpSetADVRef;
        LPSETSIGNALVREF         lpSetSignalVRef;
        LPSAVEPARAM             lpSaveParam;

        __fastcall TfmMain(TComponent* Owner);
        void vDllFunctions(void);
        void AddDevice(String strDev);
        void DeleteDevices(void);
        void SyncParam(void);

};
DWORD __stdcall CCDOnData(void* pArgs);
//---------------------------------------------------------------------------
extern PACKAGE TfmMain *fmMain;
//---------------------------------------------------------------------------
#endif
 