//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::EditValueKeyPress(TObject *Sender, char &Key)
{
        if (!IsFloat) {
                if (!(((Key >= '0') && (Key <= '9')) || (Key == char(8)) || (Key == char(13)))) {
                   Key = char(0);
                }
        } else if (!(((Key >= '0') && (Key <= '9')) ||
                      (Key == char(8)) || (Key == char(13)) ||
                      (Key == ',') || (Key == '.'))) Key = char(0);

        if (Key == char(13)) {
                if (!IsFloat) {
                        Value = StrToIntDef(EditValue->Text,0);
                        if (IsTint) {
                                switch(CBTimeUnit->ItemIndex) {
                                case 1: Value = Value * 1000; break;
                                case 2: Value = Value * 1000000; break;
                                }
                        }
                } else Value = EditValue->Text;//StrToFloat(EditValue->Text);
                OKPressed = true;
                Close();
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm2::FormCreate(TObject *Sender)
{
        CBTimeUnit->ItemIndex = 0;
        IsTint    = true;
        IsFloat   = true;
        OKPressed = false;
        Value     = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::FormShow(TObject *Sender)
{
        if (IsTint) CBTimeUnit->Visible = true;
        else CBTimeUnit->Visible = false;
        OKPressed = false;
        EditValue->Text = "";
        EditValue->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::BtnOKClick(TObject *Sender)
{
        if (EditValue->Text != "") {
                if (!IsFloat) {
                        Value = StrToIntDef(EditValue->Text,0);
                        if (IsTint) {
                                switch(CBTimeUnit->ItemIndex) {
                                case 1: Value = Value * 1000; break;
                                case 2: Value = Value * 1000000; break;
                                }
                        }
                } else Value = EditValue->Text;
                OKPressed = true;
                Close();
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm2::BtnCancelClick(TObject *Sender)
{
        OKPressed = false;
        Close();
}
//---------------------------------------------------------------------------
