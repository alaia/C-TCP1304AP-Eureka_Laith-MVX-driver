//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmMain *fmMain;
//---------------------------------------------------------------------------
__fastcall TfmMain::TfmMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TfmMain::vDllFunctions(void)
{
	hDLL		      = LoadLibrary("laith1.dll"); //Hier wird die DLL geladen
        lpGetbyte             = (LPGETBYTE)GetProcAddress(hDLL, "GetByte");
        lpOpenDriver          = (LPOPENDRIVER)GetProcAddress(hDLL, "OpenDriver");
        lpCloseDriver         = (LPCLOSEDRIVER)GetProcAddress(hDLL, "CloseDriver");
        lpIsDriverOpen        = (LPISDRIVEROPEN)GetProcAddress(hDLL, "IsDriverOpen");
        lpEnumDevices         = (LPENUMDEVICES)GetProcAddress(hDLL, "EnumDevices");
        lpOpenUSB             = (LPOPENUSB)GetProcAddress(hDLL, "OpenUSB");
        lpCloseUSB            = (LPCLOSEUSB)GetProcAddress(hDLL, "CloseUSB");
        lpDeviceCount         = (LPDEVICECOUNT)GetProcAddress(hDLL, "DeviceCount");
        lpCurrentDeviceIndex  = (LPCURRENTDEVICEINDEX)GetProcAddress(hDLL, "CurrentDeviceIndex");
        lpGetVID              = (LPGETVID)GetProcAddress(hDLL, "GetVID");
        lpGetPID              = (LPGETPID)GetProcAddress(hDLL, "GetPID");
        lpGetVersion          = (LPGETVERSION)GetProcAddress(hDLL, "GetVersion");
        lpGetVendorName       = (LPGETVENDORNAME)GetProcAddress(hDLL, "GetVendorName");
        lpGetProductName      = (LPGETPRODUCTNAME)GetProcAddress(hDLL, "GetProductName");
        lpGetSerialNumber     = (LPGETSERIALNUMBER)GetProcAddress(hDLL, "GetSerialNumber");
        lpGetErrorString      = (LPGETERRORSTRING)GetProcAddress(hDLL, "GetErrorString");
        lpResumeAquisition    = (LPRESUMEACQUISITION)GetProcAddress(hDLL, "resumeacquisition");
        lpSetMode             = (LPSETMODE)GetProcAddress(hDLL, "SetMode");
        lpStart               = (LPSTART)GetProcAddress(hDLL, "Start");
        lpStartDarkSignal     = (LPSTARTDARKSIGNAL)GetProcAddress(hDLL, "StartDarkSignal");
        lpClearDarkSignal     = (LPCLEARDARKSIGNAL)GetProcAddress(hDLL, "ClearDarkSignal");
        lpSetTint             = (LPSETTINT)GetProcAddress(hDLL, "SetTint");
        lpReadParams          = (LPREADPARAMS)GetProcAddress(hDLL, "ReadParams");
        lpWriteI2C            = (LPWRITEI2C)GetProcAddress(hDLL, "WriteI2C");
        lpReadI2C             = (LPREADI2C)GetProcAddress(hDLL, "ReadI2C");
        lpSetSystemVRef       = (LPSETSYSTEMVREF)GetProcAddress(hDLL, "SetSystemVRef");
        lpSetADVRef           = (LPSETADVREF)GetProcAddress(hDLL, "SetADVRef");
        lpSetSignalVRef       = (LPSETSIGNALVREF)GetProcAddress(hDLL, "SetSignalVRef");
        lpSaveParam           = (LPSAVEPARAM)GetProcAddress(hDLL, "SaveParam");
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::FormCreate(TObject *Sender)
{
        Cardinal RetVal;
        WORD i;

        //Series1->FastPen = true;
        Series1->AutoRepaint = false;
        for (i=0;i<3648;i++) Series1->AddXY(i,0);

        vDllFunctions();
        RetVal = lpOpenDriver();
        if (RetVal == 0) StatusBar->Panels->Items[1]->Text = "Driver is Open";
        else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::FormCloseQuery(TObject *Sender, bool &CanClose)
{
        lpCloseDriver();
        FreeLibrary(hDLL);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::Exit1Click(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::Enumerate1Click(TObject *Sender)
{
        Shortint Cnt, i;
        DWORD RetVal;
        String txt;

        DeleteDevices();
        RetVal = lpEnumDevices(Cnt);
        if (RetVal == 0)
        {
          if(Cnt > 0) {
            StatusBar->Panels->Items[1]->Text = IntToStr(Cnt)+" device(s) found";
            for (i=0;i<Cnt;i++) {
              txt = lpGetProductName(i);
              txt = txt + " ";
              txt = txt + lpGetSerialNumber(i);
              AddDevice(txt);
            }
            RetVal = lpOpenUSB(0,CCDOnData);
            if ( RetVal == 0) {
                Devices1->Items[3]->Checked = true;
                CloseDevice1->Enabled = true;
                StatusBar->Panels->Items[1]->Text = "USB DEVICE READY";
                SyncParam();
            } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
          } else StatusBar->Panels->Items[1]->Text = IntToStr(Cnt)+" device(s) found";
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------
void TfmMain::AddDevice(String strDev)
{
        TMenuItem *NewItem = new TMenuItem(Devices1); // create new device
        NewItem->Caption = strDev;
        NewItem->RadioItem = true;
        NewItem->OnClick = SelectDevClick;
        Devices1->Add(NewItem); // add it to the menu
}
//---------------------------------------------------------------------------
void TfmMain::DeleteDevices(void)
{
        // delete all devices from list
        while (Devices1->Count > 3) Devices1->Delete(3);
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::SelectDevClick(TObject *Sender)
{
        DWORD RetVal;
        TMenuItem* pMenuItem = dynamic_cast<TMenuItem*>(Sender);

        // in order to open a device just pass the index of that device
        // and the start function of data thread
        RetVal = lpOpenUSB(pMenuItem->MenuIndex - 3,CCDOnData);
        if (RetVal == 0) {
                CloseDevice1->Enabled = true;
                pMenuItem->Checked = true;
                StatusBar->Panels->Items[1]->Text = "USB DEVICE READY";
                SyncParam();
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::CloseDevice1Click(TObject *Sender)
{
        DWORD RetVal;

        RetVal = lpCloseUSB();
        if  (RetVal == 0) {
                CloseDevice1->Enabled = false;
                CloseDevice1->Checked = true;
                StatusBar->Panels->Items[1]->Text = "USB DEVICE CLOSED";
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

//******************************************************************************
//The function CCDOnData is a THREAD.
//This thread would start if CCD data are available.
//This function should return after reading CCD data.
//The return value "RESULT" is the return value of the function "resumeacquisition";
//******************************************************************************
DWORD __stdcall CCDOnData(void* pArgs)
{
        typedef struct TRec {
                WORD    len;
                short int data[3648];
        } stRec ;
        TRec* pRec = (TRec*)pArgs;
        WORD i;
        int Index;


        fmMain->Series1->Active = false;
        for (i=0;i<pRec->len;i++) {
                fmMain->Series1->YValues->Value[i] = pRec->data[i];
        }
        fmMain->Series1->Active = true;

        return fmMain->lpResumeAquisition();
}
//---------------------------------------------------------------------------
void TfmMain::SyncParam(void)
{
        DWORD RetVal;
        stCCDParam ccdparam;
        float tmp;

        RetVal = lpReadParams(ccdparam);
        if (RetVal == 0) {
                BtnStop->Enabled = ccdparam.ucStart;
                BtnStart->Enabled = !BtnStop->Enabled;
                switch(ccdparam.ucMode) {
                        case 1: Single1->Checked = true; break;
                        case 2: Run1->Checked = true; break;
                        case 4: External1->Checked = true; break;
                }
                if (ccdparam.ucEdge == 0) FallingEdge1->Checked = true;
                else RisingEdge1->Checked = true;

                if (ccdparam.dwTint < 1000)
                  StatusBar->Panels->Items[3]->Text = IntToStr(ccdparam.dwTint) + "�s";
                else if (ccdparam.dwTint < 1000000) {
                  tmp = ccdparam.dwTint/1000;
                  StatusBar->Panels->Items[3]->Text = Format("%f ms",&TVarRec(tmp),0);
                } else {
                  tmp = ccdparam.dwTint/1000000;
                  StatusBar->Panels->Items[3]->Text = Format("%f s",&TVarRec(tmp),0);
                }
                tmp = ccdparam.fSystemVRef;
                StatusBar->Panels->Items[5]->Text = Format("System %.4f",&TVarRec(tmp),0);
                tmp = ccdparam.fADVRef;
                StatusBar->Panels->Items[6]->Text = Format("AD %.4f",&TVarRec(tmp),0);
                tmp = ccdparam.fSignalVRef;
                StatusBar->Panels->Items[7]->Text = Format("Signal %.4f",&TVarRec(tmp),0);
                StatusBar->Panels->Items[1]->Text = "READ PARAMS OK";
        } else  StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::SyncParam1Click(TObject *Sender)
{
  SyncParam();        
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::ModeClick(TObject *Sender)
{
        DWORD RetVal;
        BYTE ucMode, ucEdge;
        String stri;
        TMenuItem* pMenuItem = dynamic_cast<TMenuItem*>(Sender);

        // we set the mode
        if (pMenuItem->Name == "Single1") {
        // single mode, Software trigger
        // acquisstion starts after calling the following function
                stri   = "SINGLE";
                ucMode = 0x01;
        } else if (pMenuItem->Name == "Run1") {
        // acquisition is done continuously
                stri   = "RUN";
                ucMode = 0x02;
        } else if (pMenuItem->Name == "FallingEdge1") {
        // acquisition is done on external external event
        // Trigger is falling edge sensitive
                stri   = "EXTERNAL - FALLING EDGE";
                ucMode = 0x04;
                ucEdge = 0x00;
        } else if (pMenuItem->Name == "RisingEdge1") {
        // acquisition is done on external external event
        // Trigger is rising edge sensitive
                stri   = "EXTERNAL - RISING EDGE";
                ucMode = 0x04;
                ucEdge = 0x01;
        } else {
                stri   = "Single";
                ucMode = 0x01;
        }

        //set mode
        RetVal = lpSetMode(ucMode,ucEdge);
        if (RetVal == 0) {
                StatusBar->Panels->Items[1]->Text = "MODE CHANGED - " + stri;
                switch(ucMode) {
                        case 1: Single1->Checked = true; break;
                        case 2: Run1->Checked = true; break;
                        case 4: External1->Checked = true;
                                if (ucEdge == 0) FallingEdge1->Checked = true;
                                else RisingEdge1->Checked = true;
                                break;
                        default:
                                if ((ucMode & 0x80) == 0x80) {
                                  StatusBar->Panels->Items[1]->Text = "CCD IS RUNNING; UNABLE TO CHANGE MODE";
                                } else
                                  StatusBar->Panels->Items[1]->Text = "UNKNOWN ERROR; UNABLE TO CHANGE MODE";
                                break;
                }

        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::IntegrationTime1Click(TObject *Sender)
{
        DWORD RetVal;
        DWORD Tint;
        float tmp;

        Form2->IsTint = true;
        Form2->IsFloat = false;
        Form2->Caption = "Integration Time";
        Form2->ShowModal();

        if (Form2->OKPressed) {
                Tint = Form2->Value;
                // set integration time in micro seconds (�s)
                // Tint is between 10 (10�s) and 70000000 (70s)
                RetVal = lpSetTint(Tint);
                if (RetVal == 0) {
                        if (Tint < 1000)
                          StatusBar->Panels->Items[3]->Text = IntToStr(Tint) + "�s";
                        else if (Tint < 1000000) {
                          tmp = Tint/1000;
                          StatusBar->Panels->Items[3]->Text = Format("%f ms",&TVarRec(tmp),0);
                        } else {
                          tmp = Tint/1000000;
                          StatusBar->Panels->Items[3]->Text = Format("%f s",&TVarRec(tmp),0);
                        }
                } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
        }
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::SystemVRef1Click(TObject *Sender)
{
        DWORD RetVal;
        BYTE isupdated;
        float tmp;

        Form2->IsTint  = false;
        Form2->IsFloat = true;
        Form2->Caption = "System VRef";
        Form2->ShowModal();
        if (Form2->OKPressed) {
                tmp = Form2->Value;
                // we should adjust the system reference voltage
                // usually it is 3.3V, but the accurate value is little bit different
                // and it about 3.27V, so we have to adjust it if needed.
                // This value is already adjusted at delivery, so we do not need to change it
                RetVal = lpSetSystemVRef(tmp,isupdated);
                if (RetVal == 0) {
                        if (isupdated == 1) {
                          StatusBar->Panels->Items[5]->Text = Format("System %.4f",&TVarRec(tmp),0);
                          StatusBar->Panels->Items[1]->Text = "SYSTEM_VREF OK";
                        } else StatusBar->Panels->Items[1]->Text = "UNABLE TO SET SYSTEM_VREF";
                } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
        }
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::ADVRef1Click(TObject *Sender)
{
        DWORD RetVal;
        float tmp;
        BYTE  isupdated;

        Form2->IsTint  = false;
        Form2->IsFloat = true;
        Form2->Caption = "AD VRef";
        Form2->ShowModal();
        if (Form2->OKPressed) {
                tmp = Form2->Value;
                // we may also set the AD-Converter reference voltage
                // the maxmium reference voltage is equal to the system reference voltage
                // changng this value may be usefull, if we knew that the ccd signal would never
                // exceed a certain value (e.g. 1,6V)
                // suppose that the CCD signal would never exceed the value 1.6V
                // this means we would get more accurate values.
                // the AD-converter has a 10bit resolution, this means:
                // @3.3V => 3.3V/1024 = 0,00322V (AD-Converter resolution)
                // @1,6V => 1.6V/1024 = 0,00156V
                RetVal = lpSetADVRef(tmp,isupdated);
                if (RetVal == 0) {
                        if (isupdated == 1) {
                          StatusBar->Panels->Items[6]->Text = Format("AD %.4f",&TVarRec(tmp),0);
                          StatusBar->Panels->Items[1]->Text = "AD_VREF OK";
                        } else StatusBar->Panels->Items[1]->Text = "UNABLE TO SET AD_VREF";
                } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
        }
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::SignalVRef1Click(TObject *Sender)
{
        DWORD RetVal;
        float tmp;
        BYTE  isupdated;

        Form2->IsTint  = false;
        Form2->IsFloat = true;
        Form2->Caption = "Signal VRef";
        Form2->ShowModal();
        if (Form2->OKPressed) {
                tmp = Form2->Value;
                // this is the signal offset
                RetVal = lpSetSignalVRef(tmp,isupdated);
                if (RetVal == 0) {
                        if (isupdated == 1) {
                          StatusBar->Panels->Items[7]->Text = Format("Signal %.4f",&TVarRec(tmp),0);
                          StatusBar->Panels->Items[1]->Text = "SIGNAL_VREF OK";
                        } else StatusBar->Panels->Items[1]->Text = "UNABLE TO SET SIGNAL_VREF";
                } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
        }
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::SaveParameter1Click(TObject *Sender)
{
        DWORD RetVal;
        BYTE  SaveOK;

        // issue this function in order to save the actual settings into the eeprom
        // these settings are:
        // - integration time
        // - System Reference Voltage
        // - AD-Converter Reference Voltage
        // - Signal (OffSet) Reference Voltage

        RetVal = lpSaveParam(SaveOK);
        if (RetVal ==0) {
        // if SaveOK was set to 1, then parameters were saved into the eeprom
                if (SaveOK == 1)
                        StatusBar->Panels->Items[1]->Text = "PARAMETER SAVED";
                else StatusBar->Panels->Items[1]->Text = "UNABLE TO SAVE PARAMETER";
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::DarkSignal1Click(TObject *Sender)
{
        BYTE ucStart, ucMode, ucEdge;
        DWORD RetVal;

        // determine and read darksignal
        // Darksignal values are stored into RAM of the device
        ucStart = 0x01;
        RetVal = lpStartDarkSignal(ucStart,ucMode,ucEdge);
        if (RetVal == 0) {
                if (ucMode == 0x08) StatusBar->Panels->Items[1]->Text = "DARK SIGNAL OK";
                else {
                        BtnStop->Enabled = ucStart;
                        BtnStart->Enabled = !BtnStop->Enabled;
                        switch (ucMode) {
                        case 1: Single1->Checked = true;
                        case 2: Run1->Checked = true;
                        case 4: External1->Checked = true;
                        }
                        if (ucEdge == 0x00) FallingEdge1->Checked = true;
                        else RisingEdge1->Checked = true;
                        StatusBar->Panels->Items[1]->Text = "UNABLE TO MEASURE DARK SIGNAL";
                }
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::ClearDarkSignal1Click(TObject *Sender)
{
        DWORD RetVal;

        RetVal = lpClearDarkSignal();
        if (RetVal == 0) StatusBar->Panels->Items[1]->Text = "CLEAR DARK SIGNAL OK";
        else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::BtnStartClick(TObject *Sender)
{
        BYTE  ucStart, ucMode, ucEdge;
        DWORD RetVal;

        ucStart = 0x01;
        // start acquisition
        // we do not need to initialize the parameter ucMode and ucEdge
        RetVal = lpStart(ucStart,ucMode,ucEdge);
        if (RetVal == 0) {
        // now ucMode and ucEdge contains the actual settings
                switch (ucMode) {
                        case 1: Single1->Checked = true;
                                break;
                        case 2: Run1->Checked = true;
                                BtnStop->Enabled  = true;
                                BtnStart->Enabled = false;
                                break;
                        case 4: External1->Checked = true;
                                BtnStop->Enabled  = true;
                                BtnStart->Enabled = false;
                                if (ucEdge == 0) FallingEdge1->Checked = true;
                                else RisingEdge1->Checked = true;
                                break;
                }
                StatusBar->Panels->Items[1]->Text = "CCD START OK";
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::BtnStopClick(TObject *Sender)
{
        BYTE  ucStart, ucMode, ucEdge;
        DWORD RetVal;

        ucStart = 0x00;
        // stop acquisition
        // we do not need to initialize the parameter ucMode and ucEdge
        RetVal = lpStart(ucStart,ucMode,ucEdge);
        if (RetVal == 0) {
        // now ucMode and ucEdge contains the actual settings
                switch (ucMode) {
                        case 1: Single1->Checked = true; break;
                        case 2: Run1->Checked = true; break;
                        case 4: External1->Checked = true;
                                if (ucEdge == 0) FallingEdge1->Checked = true;
                                else RisingEdge1->Checked = true;
                                break;
                }
                BtnStop->Enabled  = false;
                BtnStart->Enabled = true;
                StatusBar->Panels->Items[1]->Text = "CCD STOP OK";
        } else StatusBar->Panels->Items[1]->Text = lpGetErrorString(RetVal);
}
//---------------------------------------------------------------------------

