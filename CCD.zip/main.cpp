#include <iostream>
#include "wlaith1.h"

using namespace std;

int main()
{
    cout << "Num. de dispositivos encontrados: " << cx_enumdevices() << endl;

    return 0;
}
