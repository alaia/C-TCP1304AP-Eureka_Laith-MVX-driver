#ifndef WLAITH1_H_INCLUDED
#define WLAITH1_H_INCLUDED
//---------------------------------------------------------------------------

#define DLL_API extern "C" __declspec(dllimport)

//------ Common Constants - NULL ------

#ifdef	NULL
#  undef NULL
#endif
#ifndef __cplusplus
#  define NULL ((void *)0)
#else
#  define NULL 0
#endif

//------ Constants ------
#define RET_OK          0x00000000

#define _512            512
#define _1kB            (_512 * 2)
#define _2kB            (_1kB * 2)
#define _4kB            (_2kB * 2)
#define _8kB            (_4kB * 2)
#define _16kB           (_8kB * 2)
#define _32kB           (_16kB * 2)
#define _64kB           (_32kB * 2)
#define _128kB          (_64kB * 2)
#define _256kB          (_128kB * 2)
#define _512kB          (_256kB * 2)
#define _1MB            (_512kB * 2)
#define _2MB            (_1MB * 2)
#define _4MB            (_2MB * 2)
#define _8MB            (_4MB * 2)
#define _16MB           (_8MB * 2)
#define _32MB           (_16MB * 2)
#define _64MB           (_32MB * 2)
#define _128MB          (_64MB * 2)
#define _256MB          (_128MB * 2)

#define _1ms			1
#define _1s				(1000 * _1ms)

#define CCD_WIDTH		(3648 * 2)

#define CCD_STOP        0x00
#define CCD_START       0x01
#define SINGLE_MODE     0x01
#define RUN_MODE	    0x02
#define EXT_MODE	    0x04
#define DARK_MODE	    0x08
#define MODE_DENIED_BIT 0x80
#define RISING_EDGE     0x00
#define FALLING_EDGE    0x01

typedef struct {
	unsigned char ucStart;
    unsigned char ucMode;
    unsigned char ucEdge;
    unsigned int dwTint;
    float fSystemVRef;
    float fADVRef;
    float fSignalVRef;
} stCCDParams;

//------ DLL Functions------
DLL_API unsigned int cx_initialize(unsigned int, unsigned int, int, char*);
DLL_API int cx_enumdevices(void);
DLL_API unsigned int cx_opendevicebyindex(char);
DLL_API unsigned int cx_opendevicebyserial(char*);
DLL_API unsigned int cx_closedevice(void);
DLL_API unsigned char cx_devicecount(void);
DLL_API char cx_currentdeviceindex(void);
DLL_API unsigned int cx_waitforpipe(unsigned int);
DLL_API unsigned int cx_getpipe(void*, unsigned int, unsigned int&);
DLL_API unsigned int cx_getversion(unsigned char);
DLL_API char* cx_getvendorname(unsigned char);
DLL_API char* cx_getproductname(unsigned char);
DLL_API char* cx_getserialnumber(unsigned char);
DLL_API char* cx_geterrorstring(unsigned int);
DLL_API char* cx_geti2cstatusstring(unsigned short);
DLL_API unsigned int cx_writei2c(unsigned char, void*, unsigned short, unsigned short&, unsigned int);
DLL_API unsigned int cx_writei2cpchar(unsigned char, char*, unsigned short, unsigned short&, unsigned int);
DLL_API unsigned int cx_readi2c(unsigned char, void*, unsigned short&, unsigned short&, unsigned int);

DLL_API unsigned int cx_setmode(unsigned char&, unsigned char&, unsigned int);
DLL_API unsigned int cx_start(unsigned char&, unsigned char&, unsigned char&, unsigned int);
DLL_API unsigned int cx_startdarksignal(unsigned char&, unsigned char&, unsigned char&, unsigned int);
DLL_API unsigned int cx_cleardarksignal(unsigned int);
DLL_API unsigned int cx_settint(unsigned int&, unsigned int);
DLL_API unsigned int cx_readparams(stCCDParams&, unsigned int);
DLL_API unsigned int cx_setsystemvref(double, unsigned int);
DLL_API unsigned int cx_setadvref(double, unsigned int);
DLL_API unsigned int cx_setsignalvref(double, unsigned int);
DLL_API unsigned int cx_saveparam(unsigned int);

#endif // WLAITH1_H_INCLUDED
